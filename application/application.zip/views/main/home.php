<!DOCTYPE html>
<!-- https://www.etaonlineindia.com/ -->
<html class=" js no-touch svg inlinesvg svgclippaths no-ie8compat js no-touch svg inlinesvg svgclippaths no-ie8compat" style="" lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="google-site-verification" content="isJC9KWt_b8ECo_9U6idaWg0PEmf6Xpp5pmcPyOahp8" />
    <title>e Visa India | Indian Visa Online | Electronic Visa India - Evisa India</title>
    <meta name="description" content="Official Indian Visa Online, e visa India, e tourist visa India, Indian Visa Application for All Nationalities, Call 24X7 Customer Care" />
    <meta name="keywords" content="Apply Indian Visa Online, India Visa, Indian visa, e Visa India, e Tourist Visa India, Indian visa on arrival, Urgent Visa for India"/>
    <meta charset="utf-8">
    <link rel="canonical" href="https://www.etaonlineindia.com/" />
    <meta name="page-topic" content="Official Indian Visa Online" />
    <meta name="copyright" content="E-Visa India" />
    <meta name="author" content="E-Visa India" />
    <meta name="robots" content="index, follow" />
    <meta name="rating" content="safe for kids" />
    <meta name="googlebot" content=" index, follow " />
    <meta name="YahooSeeker" content="Index, Follow">
    <meta name="bingbot" content="INDEX, FOLLOW">
    <meta name="Robots" content="INDEX, FOLLOW"/>
    <meta name="reply-to" content="support@etaonlineindia.com" />
    <meta name="allow-search" content="yes" />
    <meta name="revisit-after" content="daily" />
    <meta name="distribution" content="global" />
    <meta name="expires" content="never" />
    <meta http-equiv="content-language" content="english" />
    <meta name="doc-type" content="Public">
    <link rel="stylesheet" href="<?=THEME?>custom/style.css">
    <link rel="stylesheet" href="<?=THEME?>custom/css-main.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">


    <link rel="stylesheet" type="text/css" href=<?=THEME?>custom/"style.css" />
    <script type="text/javascript" src="engine1/jquery.js"></script>

</head>
<!--Begin wapper-->
<body>

<!--Begin wapper-->
<div id="wrapper">
    <header>
        <div class="mainCntr">
            <!--Begin logo-->
            <div class="logo">
                <a href="index.html"><img src="<?=THEME?>custom/banner1.png" alt="e-Tourist Visa" title="e-Tourist Visa"></a>
                <!-- <h4 style="font-size: 26px;font-family: Mistral;font-weight: 100;margin-left: 63px;margin-top: -16px; color: #000;margin-bottom: 10px;">Government of India Scheme</h4>-->
            </div>
            <!--<div class="blank"><p class="blink" style="text-align:justify;margin-left:65px;font-weight:normal">The phone lines will be down today due to the technical issue, the services will resume tomorrow morning at 10 am. The applications will be processed as usual and for any query please email at </br>support@etaonlineindia.com</p></div>-->
            <!--end logo-->
            <!--Begin right-side-->
            <div class="right_side">
                <!--<span><a href="https://www.etaonlineindia.com/"><img src="contact-us.png" title="etaonlineindia contact" alt="etaonlineindia"/></a></span>-->
            </div>
            <!--end right-side-->
        </div>
        <div style="clear:both;"></div>
        <div class="bg">
            <div id="nav">
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="apply_now.html" class="active">Apply Now</a></li>
                    <!--<li><a href="holiday.php">Holiday</a></li>
                    <li><a href="index.php">Flight</a></li>
                    <li><a href="flight/hotel.php">Hotel</a></li>-->

                    <li>
                        <a href="document_requirement.html">Document Requirement</a>
                    </li>
                    <li>
                        <a href="privacy_policy.html">Privacy Policy</a>
                    </li>
                    <li>
                        <a href="terms-conditions.html">Terms Conditions</a>
                    </li>
                    <li>
                        <a href="about_us.html">About Us</a>
                    </li>
                    <li>
                        <a href="contact.html">Contact Us</a>
                    </li>

                </ul>
            </div>
        </div>
    </header>
    <!--Begin banner-->
    <div class="clearfix"></div>
    <section class="banner">
        <div class="banner_bg">
            <ul>
                <li><img src="<?=THEME?>custom/slide-banner.jpg" style="height:300px; margin-top: 0px;" alt=""></li>
            </ul>



        </div>



    </section>
    <!--end banner-->

    <div class="clearfix"></div>
    <!--Begin maincntr-->

    <div class="mainCntr">
        <!--Begin button_bottom-->
        <section class="bottom_btn" style="margin-top: 60px;">
            <div class="frt_bt"><p style="margin-top: 10px;"><a  href="apply_now.html">Click here to Apply <br>for Visa</a></p></div>
            <div class="frt_bt1"><p style="margin-top: 10px;"><a href="append.html">Amend or Complete Partialy<br>Filled Form</a></p></div>
            <div class="frt_bt2"><p style="margin-top: 10px;"><a href="https://www.etaonlineindia.com/welcomevisa/complete_payment">Make Payment for<br>Completed Form</a></p></div>
            <!--	<div class="frt_bt3"><p><a href="">Check Application<br> Status</a></p></div>-->
            <!--div class="frt_bt4"><p><a href="">Visa Status </a></p></div--->
        </section>
        <!--Begin information-->
        <div class="main_ara_new">

            <section class="main_ara">
                <!--Begin left_menu-->
                <div class="left_bar">

                    <div class="left_bar_inner">
                        <h3 style=" margin:-10px 0px 10px 0px;"><img src="c6.png" />24/7 Customer Care</h3>
                        <!--<ul>
                        <li class="contact-mail" style="background:url(c5.png) no-repeat 2%;">support@etaonlineindia.com</li>
                            <li class="contact-mail1" style="background:url(c2.png) no-repeat 2%;">USA +1 630 239 8437</li>
                            <li class="contact-mail1" style="background:url(c1.png) no-repeat 2%;">UK +44 203 500 2749</li>
                            <li class="contact-mail1" style="background:url(c3.png) no-repeat 2%;">AUS +61 924 107 380</li>
                            <li class="contact-mail1" style="background:url(c4.png) no-repeat 2%;">IND +91 97 6651 7499</li>

                            <li style="font-size: 13px;font-family: Tahoma,Geneva,sans-serif;background:transparent;border-bottom: none;color: #0082dc;padding: 8px 0px 8px 38px;">Worldwide phone support</li>

                        </ul>-->
                        <img src="<?=THEME?>custom/contact-us.png"  />
                    </div>


                    <div class="left_bar_inner" style="margin-top: -1px;">
                        <h3 style=" margin:0px 0px 10px 0px;">e-Visa Information</h3>
                        <ul>
                            <li><a href="https://www.etaonlineindia.com/apply-visa">e-Visa India</a></li>
                            <li><a href="https://www.etaonlineindia.com/e-tourist-visa">Tourist E-visa</a></li>
                            <li><a href="https://www.etaonlineindia.com/emergency-e-visa-to-india">Emergency E-visa</a></li>
                            <li><a href="https://www.etaonlineindia.com/how-to-apply-for-an-indian-evisa">How to apply for an Indian E-visa</a></li>
                            <li><a href="https://www.etaonlineindia.com/indian-business-e-visa">Indian Business E-visa</a></li>
                            <li><a href="https://www.etaonlineindia.com/about-us">About Us</a></li>
                            <!--<li><a href="https://www.etaonlineindia.com/">FAQs-Payment Related</a></li>-->
                        </ul>
                    </div>


                    <div class="left_bar_inner">
                        <img src="<?=THEME?>custom/3dsecure.gif" alt="" style="width: 250px;" />
                    </div>
                    <div> <a href="https://seal.godaddy.com/verifySeal?sealID=ToodJd4tH09uOzItvUykMobyFs0dCU6CU3umcLputvll3Xe2uZDoxK3UexQk" target="_blank"><img src="images/godaddy_security_seal.png" alt="" /></a>
                    </div>
                    <!--<div class="left_bar_inner">
                      <img src="digital-india.png" alt="" style="width: 250px;" />
                    </div>-->


                </div>						<!--End left_menu-->

                <!--Begin right-panel-->
                <div class="right_area" id="tvoa">
                    <div class="right_bar_inner"><h1 style="text-transform: none; color:#fff; font-family:Tahoma,Geneva,sans-serif; font-weight:normal;font-size: 17px;text-align:center">Indian e-VISA</h1></div>

                    <!--<p><span style="line-height: 35px;">*Disclaimer:</span><br>
                     etaonlineindia.com is responsible for full visa services to India. This is a commercial website to apply for visa to India. You will be charged a fee for using our services. Our fee will be higher than Indian Government as we charge a service fee on top of the Indian Government visa fee. Read all our Terms and Conditions carefully before using our services.</p>-->


                    <p><span style="line-height: 35px;">e-Visa India</span><br>
                        e-Visa is a facility launched by The Government of India for foreigners travelling to India for the purpose of Tourism, Business or short term medical treatment. Passengers must have a valid passport and a print out of the Visa approval letter sent to their email before leaving the respective country they are travelling from.</p>

                    <p><span>Fast Track Processing:</span><br>
                        For Fast Track service you must choose the "Urgent Processing" from the dropdown in the application. You can avail this facility by paying additional charges in case of urgent travels. e-Visa application can be processed on Fast track basis after paying the relevant charges. To avail the expedited service, your travel date must be at least after 72 hours from the time your submit the application. For any assistance you may contact customer care number.</p>

                    <p><span style="color:#1028d0;">Important Note:</span><br>
                        It is extremely important to understand that once an application is initiated or submitted then you must not start or submit another application against the same passport number.<strong style="color: #0082dc;">Any and all subsequent applications shall be rejected by the Government of India due to redundancy/duplicity. It is strictly advised to finish and complete only one application and not submit more than one application. You shall not be granted any other visa against the same passport till the time your previous visa is still valid even if any details are incorrect in the visa. </strong>Once an application is submitted or visa is granted against a passport, it cannot be cancelled, amended or refunded. Applicants are advised to be utmost careful about the details submitted in the applications and must review before finally making the payment. It is strictly advised not submit more than one applications at the same time and only the same application be completed that was initiated. If there is any query about duplicity/redundancy then you must contact immediately on the 24/7 Customer care number and get it checked before proceeding further to avoid any kind of hassle.</p>

                    <p><span>e-Visa Facility:</span><br>
                        e-Visa is valid for 60 days from the date of arrival. It must be availed within its period of validity. If you are travelling with the purpose of Tourism or Business then it will be valid for two entries and for Medical purpose it will be valid for three entries from the date of the first arrival date in India. It allows a maximum of two visits in a calendar year. The facility is valid for entry through 25 designated Airports (i.e. Ahmedabad, Amritsar, Bagdogra, Bengaluru, Calicut, Chennai, Chandigarh,Cochin, Coimbatore, Delhi, Gaya, Goa, Guwahati, Hyderabad, Jaipur, Kolkata, Lucknow, Mangalore, Mumbai, Nagpur, Pune, Tiruchirapalli, Trivandrum, Varanasi & Visakhapatnam) and 5 designated seaports (i.e. Mumbai, Chennai, Cochin, Goa and Mangalore). However, the foreigner can take exit from any of the authorized Immigration Check Posts (ICPs) in India.</p>

                    <p><span>Documents Checklist:</span></p>
                    <ul class="tvoa_instructions">
                        <li>Passport must have a validity of at least six months from the date of arrival in India.</li>
                        <li>The passport must have at least two blank pages in case stamping needed to be done by the Immigration Officer.</li>
                        <li>International Travellers are required to have a return ticket or an onward journey ticket and may be asked at the airpport to be furnished.</li>
                        <li>Tourists must travel with sufficient money to spend during the stay in India.</li>
                        <li>For Business Travel one must have his or her business card or a letter from the company for the purpose of travel.</li>
                        <li>For Medical Purpose, a person must have a letter from the Hospital on their letterhead where the treatment is supposed to happen.</li>
                    </ul>

                    <p><span>Eligibility</span></p>
                    <ul class="tvoa_instructions">
                        <li>
                            Applicants of the eligible countries are requested to apply online minimum 4 days in advance of the date of arrival with a window of 180 days.
                        </li>
                        <li>Pakistani Passport Holders are not eligible for this facility, they should apply through the local Embassy or Consulate.
                        </li>
                        <li>One can avail this facility only on passport, travel documents are not eligible for this scheme</li>
                        <li>
                            This facility of not available for Diplomatic or Official passport holders.
                        </li>
                        <li>Each Individual must apply separately on their passport. Children travelling on parents passport are not eligible for this scheme.</li>
                        <li>The delivery times are not applicable for Sri Lankan and Chinese Passport Holders. For these nationalities the delivery time is 5 business days in case of urgent processing and 10 business days in case of normal processing.</li>
                    </ul>







                </div>
            </section>

            <!-- <section class="visa_process">
          <div class="block-index">
<h2><a href="" target="_self" title="EXTRA SERVICES" style="color:#ff9933;">SERVICES PROVIDED BY E-VISA INDIA</a></h2>
<a href="" title="Extra Service" target="_self"><div class="icon-services"></div></a>
<ul style="margin-left: 70px;">-->
            <!-- <li> Airport Transfers. </li>
             <li> Tour Guide arrangement</li>
             <li> Other Holiday Services </li>
             <li> Accomodation Service </li>
             <li> Local Tour Arrangements </li>
             <li> Sri Lanka and Myanmar VOA </li>-->
            <!-- <li><strong class="red">Customer Care:</strong> Customer Care available 24X7 Over the Phone as well as email.</li>
               <li><strong class="red">Processing:</strong> Maximum 4-7 days processing time.</li>
               <li><strong class="red">Quality Check:</strong> Quality Check and Required Correction is done against all the information and documents provided in the applications in order to achieve maximum approval ratio.</li>
           </ul>
 </div>
 <div class="block-index">
   <h2><a href="http://evisaindia.org.in/" target="_self" title="5 REASONS TO CHOOSE INDIA E-VISA" style="color:#ff9933;">5 REASONS TO CHOOSE E-VISA INDIA</a></h2>
   <a href="http://evisaindia.org.in/" title="5 REASONS TO CHOOSE INDIA E-VISA" target="_self"><div class="icon-reason"></div></a>
   <ul style=" margin-left: 22px;    margin-top: 31px;">
 <li><strong class="red">Hassle-free:</strong>Completely online procedure, no paper work involved.</li>

 <li><strong class="red">Convenient:</strong> Applicable for selective Nationalities for Air and Sea Routes.</li>

 <li><strong class="red">Cheaper:</strong> Fixed fees, no hidden charges</li>
 <li><strong class="red">More accessible:</strong> Quickes and most relaible method of getting Indian Visa.</li>
</ul>    </div>
 <div class="block-index" style="background:none;">

   <h2 style="margin:2px 0 10px 0;"><a href="" target="_self" title="INDIA E-VISA LASTEST NEWS" style="color:#ff9933;">E-VISA INDIA LASTEST NEWS</a></h2>
     <a href="" title="INDIA E-VISA LASTEST NEWS" target="_self"><div class="icon-news"></div></a>

  <ul style="margin-left: 40px; margin-top: 23px;">
     <li> <a href="">More Than 700 Per cent Increase in Tourist Arrivals on E-Visa.</a> </li>
     <li> <a href="">India saw a jump in foreign tourists in April 2017.</a> </li>

   </ul>

 </div>

             </section>-->

            <!--End information-->
            <!--Begin visa process-->
            <section class="visa_process">
                <div class="visa_process_inner"><h4>e-Visa India PROCESS</h4></div>

                <div class="creat">
                    <!--div class="arw"><img src="Indian%20e-Tourist%20Visa_files/arrow_01.png"></div--->

                    <div class="htw">
                        <div class="how_it">

                        </div>
                        <span style="margin-left: 55px;">Step 1</span>
                        <div class="how_mid box_1" style="float: right;">
                            <img src="<?=THEME?>custom/1.png">
                        </div>
                    </div>

                    <h2 onClick="verify()" style="cursor:pointer;margin-left: 184px;">Apply online</h2>
                    <!--<p>Upload Photo and Passport Page</p>-->
                </div>

                <div class="creat">
                    <!--div class="arw"><img src="Indian%20e-Tourist%20Visa_files/arrow_02.png"></div--->
                    <div class="htw">
                        <div class="how_it"></div>
                        <span style=" margin-left: -39px;">Step 2</span>
                        <div class="how_mid box_1"><img src="<?=THEME?>custom/2.png"></div>
                    </div>
                    <a class="h2a" target="_blank" href="https://www.etaonlineindia.com/welcomevisa/complete_payment">Pay visa fee online</a>
                    <!-- <h2>Pay visa fee online </h2>-->
                    <!-- <p> Using Credit / Debit card </p>-->
                </div>

                <div class="creat">
                    <!--div class="arw"><img src="Indian%20e-Tourist%20Visa_files/arrow_01.png"></div-->
                    <div class="htw">
                        <div class="how_it"></div>
                        <span style=" margin-left: -131px;">Step 3</span>
                        <div class="how_mid box_1" style=" float: left;"><img src="<?=THEME?>custom/3.png"></div>
                    </div>
                    <h2 style=" margin-left: -182px;">Receive e-Visa Electronically</h2>
                    <!-- <p> eTV Will be sent to your e-mail </p>-->
                </div>

                <!--<div class="creat">
                    <div class="htw">
                        <div class="how_it"></div>
                        <span>Step 4</span>
                        <div class="how_mid box_1"><img src="./images/4.png"></div>
                    </div>
                    <h2>Fly To India</h2>
                    <p>Print eTV and carry at the time of travel</p>
                </div>-->

            </section>
            <!--End visa process-->

            <div class="clear"></div>

        </div>
    </div>
    <!--End maincntr-->
    <footer>
        <div class="mainCntr">
            <div class="footer_logo box_1"><img src="payment-options1.png">
                <p align="right" style="margin-left: -10px;">&copy;copyright 2017 by www.etaonlineindia.com</p></div>

            <div class="footer_left">
                <a href="javascript:;" target="_blank" rel="nofollow">
                    <!-- <img src="payment_options_sans_mc.gif" alt="EBS" border="0"></a>-->

            </div>

            <div class="footer_text">
                <div align="justify"><strong style="font-size:12px; font-weight: normal;">
                        <div class="footercontain" style="color:#000; text-align:justify; margin-left:10px;">
                            <div align="justify"><strong style="font-size:12px; font-weight: normal;"><b style="font-size:14px; color:#f48020;">*Disclaimer:</b>
                                    www.etaonlineindia.com website provides you e-visa services to India. This is a commercial website to apply for visa to India where you will be charged a fee for using our services. You can also apply through the direct official source. Kindly read all our Terms and Conditions carefully before using our services.
                                    <!-- etaonlineindia.com is responsible for full visa services to India. This is a commercial website to apply for visa to India. You will be charged a fee for using our services. Our fee will be higher than Indian Government as we charge a service fee on top of the Indian Government visa fee. You can also apply through the Indian Embassy or website online at <a href="https://indianvisaonline.gov.in/visa/index.html" target="blank">www.indianvisaonline.gov.in </a>. Read all our Terms and Conditions carefully before using our services.-->
                                </strong></div>
                        </div>
                </div>

            </div>

        </div>
    </footer>
</div>
<!--Begin wapper-->
</div></body></html>