<?php
/**
 * Created by PhpStorm.
 * User: Hitesh
 * Date: 06-Jan-19
 * Time: 10:10 PM
 * Coded by Hitesh with love
 * Find me at confused1108.github.io
 */
?>
<!DOCTYPE html>
<!-- saved from url=(0045)https://www.evisaonline.org.in/privacy-policy -->
<html class=" js no-touch svg inlinesvg svgclippaths no-ie8compat js no-touch svg inlinesvg svgclippaths no-ie8compat" style="" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>e-VISA Privacy Policy</title>


    <link rel="canonical" href="https://www.evisaonline.org.in/">
    <meta name="page-topic" content="Official Indian Visa Online">
    <meta name="copyright" content="E-Visa India">
    <meta name="author" content="E-Visa India">
    <meta name="robots" content="index, follow">
    <meta name="rating" content="safe for kids">
    <meta name="googlebot" content=" index, follow ">
    <meta name="YahooSeeker" content="Index, Follow">
    <meta name="bingbot" content="INDEX, FOLLOW">
    <meta name="Robots" content="INDEX, FOLLOW">
    <meta name="reply-to" content="support@evisaonline.org.in">
    <meta name="allow-search" content="yes">
    <meta name="revisit-after" content="daily">
    <meta name="distribution" content="global">
    <meta name="expires" content="never">
    <meta http-equiv="content-language" content="english">
    <meta name="doc-type" content="Public">
    <link rel="stylesheet" href="<?=THEME?>custom/style.css">
    <link rel="stylesheet" href="<?=THEME?>custom/css-main.css">
    <link rel="shortcut icon" href="https://www.evisaonline.org.in/favicon.ico" type="image/x-icon">
    <link rel="icon" href="https://www.evisaonline.org.in/favicon.ico" type="image/x-icon">

    <!--<link rel="stylesheet" type="text/css" href="style.css" />
        <script type="text/javascript" src="engine1/jquery.js"></script>-->
    <!--Start of Tawk.to Script-->
    <script type="text/javascript" async="" src="<?=THEME?>custom/analytics.js.download"></script><script async="" src="<?=THEME?>custom/default" charset="UTF-8" crossorigin="*"></script><script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/5aa425904b401e45400d9a38/default';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
    <!--End of Tawk.to Script-->
    <!--Google Analytices Script-->
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async="" src="<?=THEME?>custom/js"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-110581702-2');
    </script>

    <!--End-->

    <style type="text/css">@keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}@-moz-keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}@-webkit-keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}#nfYU10R-1546793002586{outline:none!important;visibility:visible!important;resize:none!important;box-shadow:none!important;overflow:visible!important;background:none!important;opacity:1!important;filter:alpha(opacity=100)!important;-ms-filter:progid:DXImageTransform.Microsoft.Alpha(Opacity1)!important;-moz-opacity:1!important;-khtml-opacity:1!important;top:auto!important;right:10px!important;bottom:90px!important;left:auto!important;position:fixed!important;border:0!important;min-height:0!important;min-width:0!important;max-height:none!important;max-width:none!important;padding:0!important;margin:0!important;-moz-transition-property:none!important;-webkit-transition-property:none!important;-o-transition-property:none!important;transition-property:none!important;transform:none!important;-webkit-transform:none!important;-ms-transform:none!important;width:auto!important;height:auto!important;display:none!important;z-index:2000000000!important;background-color:transparent!important;cursor:auto!important;float:none!important;border-radius:unset!important;}#mGn2r90-1546793002586.open{animation : tawkMaxOpen .25s ease!important;}</style></head>
<!--Begin wapper-->
<body>

<!--Begin wapper-->
<div id="wrapper">
    <header>
        <div class="mainCntr">
            <!--Begin logo-->
            <div class="logo">
                <a href="https://www.evisaonline.org.in/"><img src="<?=THEME?>custom/banner1.png" alt="e-Tourist Visa" title="e-Tourist Visa"></a>
                <!-- <h4 style="font-size: 26px;font-family: Mistral;font-weight: 100;margin-left: 63px;margin-top: -16px; color: #000;margin-bottom: 10px;">Government of India Scheme</h4>-->
            </div>
            <!--<div class="blank"><p class="blink" style="text-align:justify;margin-left:65px;font-weight:normal">The phone lines will be down today due to the technical issue, the services will resume tomorrow morning at 10 am. The applications will be processed as usual and for any query please email at </br>support@evisaonline.org.in</p></div>-->
            <!--end logo-->
            <!--Begin right-side-->
            <div class="right_side">
                <!--<span><a href="https://www.evisaonline.org.in/"><img src="contact-us.png" title="etaonlineindia contact" alt="etaonlineindia"/></a></span>-->
            </div>
            <!--end right-side-->
        </div>
        <div style="clear:both;"></div>
        <div class="bg">
            <div id="nav">
                <ul>
                    <li><a href="<?=CTRL?>">Home</a></li>
                    <li><a href="<?=CTRL?>Visa/apply_visa" class="active">Apply Now</a></li>
                    <!--<li><a href="holiday.php">Holiday</a></li>
                    <li><a href="index.php">Flight</a></li>
                    <li><a href="flight/hotel.php">Hotel</a></li>-->

                    <li>
                        <a href="<?=CTRL?>Visa/documents">Document Requirement</a>
                    </li>
                    <li>
                        <a href="<?=CTRL?>Visa/privacy">Privacy Policy</a>
                    </li>
                    <li>
                        <a href="<?=CTRL?>Visa/terms">Terms Conditions</a>
                    </li>
                    <li>
                        <a href="<?=CTRL?>Visa/about">About Us</a>
                    </li>
                    <li>
                        <a href="<?=CTRL?>Visa/contact">Contact Us</a>
                    </li>

                </ul>

            </div>
        </div>
    </header>
    <!-- Header End--><!--Begin banner-->
    <!--Begin banner-->
    <div class="clearfix"></div>
    <section class="banner">
        <div class="banner_bg">
            <ul>
                <li><img src="<?=THEME?>custom/slide-banner.jpg" style="height:300px; margin-top: -2px;" alt=""></li>
            </ul>
        </div>
    </section>
    <!--end banner-->            <!--end banner-->

    <div class="clearfix"></div>
    <!--Begin maincntr-->

    <div class="mainCntr">
        <!--Begin button_bottom-->
        <section class="bottom_btn" style="margin-top: 60px;">
            <div class="frt_bt"><p style="margin-top: 10px;"><a  href="<?=CTRL?>Visa/apply_visa">Click here to Apply <br>for Visa</a></p></div>
            <div class="frt_bt1"><p style="margin-top: 10px;"><a href="<?=CTRL?>Visa/partial">Amend or Complete Partialy<br>Filled Form</a></p></div>
            <div class="frt_bt2"><p style="margin-top: 10px;"><a href="<?=CTRL?>Visa/complete_payment">Make Payment for<br>Completed Form</a></p></div>
            <!--	<div class="frt_bt3"><p><a href="">Check Application<br> Status</a></p></div>-->
            <!--div class="frt_bt4"><p><a href="">Visa Status </a></p></div--->
        </section>
        <!--Begin information-->
        <div class="main_ara_new">

            <section class="main_ara">
                <!--Begin left_menu-->
                <div class="left_bar">

                    <div class="left_bar_inner">
                        <h3 style=" margin:-10px 0px 10px 0px;"><img src="<?=THEME?>custom/c6.png">24/7 Customer Care</h3>
                        <img src="<?=THEME?>custom/contact-us.png">
                    </div>

                    <div class="left_bar_inner" style="margin-top: -1px;">
                        <h3 style=" margin:0px 0px 10px 0px;">e-Visa Information</h3>
                        <ul>
                            <li><a href="https://www.evisaonline.org.in/apply-visa">e-Visa India</a></li>
                            <li><a href="https://www.evisaonline.org.in/e-tourist-visa">Tourist E-visa</a></li>
                            <li><a href="https://www.evisaonline.org.in/emergency-e-visa-to-india">Emergency E-visa</a></li>
                            <li><a href="https://www.evisaonline.org.in/how-to-apply-for-an-indian-evisa">How to apply for an Indian E-visa</a></li>
                            <li><a href="https://www.evisaonline.org.in/indian-business-e-visa">Indian Business E-visa</a></li>
                            <li><a href="https://www.evisaonline.org.in/indian-medical-e-visa">Indian Medical E-visa</a></li>
                            <li><a href="https://www.evisaonline.org.in/how-to-get-Indian-visa">How to get Indian Visa Online</a></li>
                            <li><a href="https://www.evisaonline.org.in/indian-e-visa-application-processing-time">Indian E-visa Application Processing Time</a></li>
                            <!--<li><a href="https://www.evisaonline.org.in/">FAQs-Payment Related</a></li>-->
                        </ul>
                    </div>

                    <div class="left_bar_inner">
                        <img src="<?=THEME?>custom/3dsecure.gif" alt="" style="width: 250px;">
                    </div>
                    <div>
                    </div>
                </div>						<!--End left_menu-->

                <!--End left_menu-->

                <!--Begin right-panel-->
                <div class="right_area" id="tvoa">
                    <div class="right_bar_inner">
                        <h1 style="text-transform: none; color:#fff; font-family:Tahoma,Geneva,sans-serif; font-weight:normal;font-size: 17px;text-align:center">e-VISA India</h1></div>

                    <p><span>Privacy-Policy </span><br>

                        This privacy policy sets out how www.evisaonline.org.in uses and protects any information that you when you use this website. E-visa India is committed to ensuring that your privacy is protected. Should we ask you to provide certain information by which you can be identified when using this website, then you can be assured that it will only be used in accordance with this privacy statement. We may change this policy from time to time by updating this page. You should check this page from time to time to ensure that you are happy with any changes. <br>
                        <br>
                        <span>We can collect the following information: </span><br>
                        Name and other personal information. Contact information including email address. Other information required to process your Indian Visa Application. <br>
                        <br>
                        <span>What we do with the gathered information: </span><br>
                        <br>
                        We require this information to process your e-visa India Application with a better service and in particular for the following reasons: Internal record keeping. We may use the information to improve our services and do the quality check on the application. We may periodically send follow up emails with respect to your application and visa grant letter. From time to time, we may also use your information to contact you to collect more information in the context of your application. We may contact you by email or phone. We may use the information to provide you access to your temporary application submitted on our website as and when required. We do not provide your information to our third party partners for any marketing or promotional activities. We will never sell your information.<br>
                        <span>Security: </span><br>
                        We are committed to ensuring that your information is secure. In order to prevent unauthorized access or disclosure we have put in place suitable physical, electronic and managerial procedures to safeguard and secure the information we collect online. <br>
                        <br>
                        <span>How we use cookies? </span><br><br>
                        A cookie is a small file which asks permission to be placed on your computer's hard drive. Once you agree, the file is added and the cookie helps analyze web traffic or lets you know when you visit a particular site. Cookies allow web applications to respond to you as an individual. The web application can tailor its operations to your needs, likes and dislikes by gathering and remembering information about your preferences. We use traffic log cookies to identify which pages are being used. This helps us analyze data about web page traffic and improve our website in order to tailor it to customer needs. We only use this information for statistical analysis purposes and then the data is removed from the system.
                        Overall, cookies help us provide you with a better website, by enabling us to monitor which pages you find useful and which you do not. A cookie in no way gives us access to your computer or any information about you, other than the data you choose to share with us. You can choose to accept or decline cookies. Most web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. This may prevent you from taking full advantage of the website.<br>
                        <br>
                        Please feel free to contact or email us, if you believe that any of your information held by us is incorrect or incomplete. We will make the necessary corrections as soon as possible.<br>
                        <br>
                    </p>

                </div>
            </section>

            <!--Begin visa process-->
            <!--Begin visa process-->
            <section class="visa_process">
                <div class="visa_process_inner"><h4>e-Visa India PROCESS</h4></div>
                <div class="creat">
                    <div class="htw">
                        <div class="how_it">
                        </div>
                        <span style="margin-left: 55px;">Step 1</span>
                        <div class="how_mid box_1" style="float: right;">
                            <img src="<?=THEME?>custom/1.png">
                        </div>
                    </div>

                    <h2 onclick="verify()" style="cursor:pointer;margin-left: 184px;">Apply online</h2>
                    <!--<p>Upload Photo and Passport Page</p>-->
                </div>

                <div class="creat">
                    <!--div class="arw"><img src="Indian%20e-Tourist%20Visa_files/arrow_02.png"></div--->
                    <div class="htw">
                        <div class="how_it"></div>
                        <span style=" margin-left: -39px;">Step 2</span>
                        <div class="how_mid box_1"><img src="<?=THEME?>custom/2.png"></div>
                    </div>
                    <a class="h2a" target="_blank" href="https://www.evisaonline.org.in/welcomevisa/complete_payment">Pay visa fee online</a>
                    <!-- <h2>Pay visa fee online </h2>-->
                    <!-- <p> Using Credit / Debit card </p>-->
                </div>

                <div class="creat">
                    <!--div class="arw"><img src="Indian%20e-Tourist%20Visa_files/arrow_01.png"></div-->
                    <div class="htw">
                        <div class="how_it"></div>
                        <span style=" margin-left: -131px;">Step 3</span>
                        <div class="how_mid box_1" style=" float: left;"><img src="<?=THEME?>custom/3.png"></div>
                    </div>
                    <h2 style=" margin-left: -182px;">Receive e-Visa Electronically</h2>
                    <!-- <p> eTV Will be sent to your e-mail </p>-->
                </div>
            </section>
            <!--End visa process-->
            <!--End visa process-->
            <div class="clear"></div>

        </div>
    </div>
    <!--End maincntr--><footer>
        <div class="mainCntr">
            <div class="footer_logo box_1"><img src="<?=THEME?>custom/payment-options1.png">
                <p align="right" style="margin-left: -10px;">©copyright 2017 by www.evisaonline.org.in</p></div>
            <span id="siteseal" style="margin-left: 22px;">
</span>
            <div class="footer_left">


            </div>

            <div class="footer_text">
                <div align="justify"><strong style="font-size:12px; font-weight: normal;">
                        <div class="footercontain" style="color:#000; text-align:justify; margin-left:10px;">
                            <div align="justify"><strong style="font-size:12px; font-weight: normal;"><b style="font-size:14px; color:#f48020;">*Disclaimer:</b>
                                    www.evisaonline.org.in website provides you e-visa services to India. This is a commercial website to apply for visa to India where you will be charged a fee for using our services. You can also apply through the direct official source. Kindly read all our Terms and Conditions carefully before using our services.
                                </strong></div>
                        </div>
                    </strong></div><strong style="font-size:12px; font-weight: normal;">

                </strong></div><strong style="font-size:12px; font-weight: normal;">

            </strong></div><strong style="font-size:12px; font-weight: normal;">
        </strong></footer><strong style="font-size:12px; font-weight: normal;">
    </strong></div><strong style="font-size:12px; font-weight: normal;">
    <!--Begin wapper-->
</strong><div id="nfYU10R-1546793002586" class="" style="display: none !important;"><iframe id="mGn2r90-1546793002586" src="<?=THEME?>custom/saved_resource.html" frameborder="0" scrolling="no" title="chat widget" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: auto !important; right: auto !important; bottom: auto !important; left: auto !important; position: static !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 350px !important; height: 520px !important; display: none !important; z-index: 999999 !important; cursor: auto !important; float: none !important; border-radius: unset !important;"></iframe><iframe id="w86JDzx-1546793002586" src="<?=THEME?>custom/saved_resource(1).html" frameborder="0" scrolling="no" title="chat widget" class="" style="outline: none !important; visibility: visible !important; resize: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; position: fixed !important; border: 0px !important; padding: 0px !important; transition-property: none !important; display: none !important; z-index: 1000001 !important; cursor: auto !important; float: none !important; box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 10px 0px !important; height: 60px !important; min-height: 60px !important; max-height: 60px !important; width: 60px !important; min-width: 60px !important; max-width: 60px !important; border-radius: 50% !important; transform: rotate(0deg) translateZ(0px) !important; transform-origin: 0px center 0px !important; margin: 0px !important; top: auto !important; bottom: 20px !important; right: 20px !important; left: auto !important;"></iframe><iframe id="dsV3CYI-1546793002587" src="<?=THEME?>custom/saved_resource(2).html" frameborder="0" scrolling="no" title="chat widget" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; position: fixed !important; border: 0px !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; display: none !important; z-index: 1000003 !important; cursor: auto !important; float: none !important; border-radius: unset !important; top: auto !important; bottom: 60px !important; right: 15px !important; left: auto !important; width: 21px !important; max-width: 21px !important; min-width: 21px !important; height: 21px !important; max-height: 21px !important; min-height: 21px !important;"></iframe><div class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: 0px !important; right: auto !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 100% !important; height: 100% !important; display: none !important; z-index: 1000001 !important; cursor: move !important; float: left !important; border-radius: unset !important;"></div><div id="YhW4rZv-1546793002586" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: 0px !important; right: auto !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 6px !important; height: 100% !important; display: block !important; z-index: 999998 !important; cursor: w-resize !important; float: none !important; border-radius: unset !important;"></div><div id="VhTndM7-1546793002586" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: 0px !important; right: 0px !important; bottom: auto !important; left: auto !important; position: absolute !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 100% !important; height: 6px !important; display: block !important; z-index: 999998 !important; cursor: n-resize !important; float: none !important; border-radius: unset !important;"></div><div id="zBNF7mt-1546793002586" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: 0px !important; right: auto !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 12px !important; height: 12px !important; display: block !important; z-index: 999998 !important; cursor: nw-resize !important; float: none !important; border-radius: unset !important;"></div><iframe id="GGStx4R-1546793002614" src="<?=THEME?>custom/saved_resource(3).html" frameborder="0" scrolling="no" title="chat widget" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: auto !important; right: 20px !important; bottom: 90px !important; left: auto !important; position: fixed !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 378px !important; height: 521px !important; display: none !important; z-index: 999999 !important; cursor: auto !important; float: none !important; border-radius: unset !important;"></iframe></div></body></html>
