<?php
/**
 * Created by PhpStorm.
 * User: Hitesh
 * Date: 06-Jan-19
 * Time: 10:10 PM
 * Coded by Hitesh with love
 * Find me at confused1108.github.io
 */
?>
<!DOCTYPE html>
<!-- saved from url=(0047)https://www.evisaonline.org.in/terms-conditions -->
<html class=" js no-touch svg inlinesvg svgclippaths no-ie8compat js no-touch svg inlinesvg svgclippaths no-ie8compat" style="" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Terms &amp; Condition</title>


    <link rel="canonical" href="https://www.evisaonline.org.in/">
    <meta name="page-topic" content="Official Indian Visa Online">
    <meta name="copyright" content="E-Visa India">
    <meta name="author" content="E-Visa India">
    <meta name="robots" content="index, follow">
    <meta name="rating" content="safe for kids">
    <meta name="googlebot" content=" index, follow ">
    <meta name="YahooSeeker" content="Index, Follow">
    <meta name="bingbot" content="INDEX, FOLLOW">
    <meta name="Robots" content="INDEX, FOLLOW">
    <meta name="reply-to" content="support@evisaonline.org.in">
    <meta name="allow-search" content="yes">
    <meta name="revisit-after" content="daily">
    <meta name="distribution" content="global">
    <meta name="expires" content="never">
    <meta http-equiv="content-language" content="english">
    <meta name="doc-type" content="Public">
    <link rel="stylesheet" href="<?=THEME?>custom/style.css">
    <link rel="stylesheet" href="<?=THEME?>custom/css-main.css">
    <link rel="shortcut icon" href="https://www.evisaonline.org.in/favicon.ico" type="image/x-icon">
    <link rel="icon" href="https://www.evisaonline.org.in/favicon.ico" type="image/x-icon">

    <!--<link rel="stylesheet" type="text/css" href="style.css" />
        <script type="text/javascript" src="engine1/jquery.js"></script>-->
    <!--Start of Tawk.to Script-->
    <script type="text/javascript" async="" src="<?=THEME?>custom/analytics.js.download"></script><script async="" src="<?=THEME?>custom/default" charset="UTF-8" crossorigin="*"></script><script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/5aa425904b401e45400d9a38/default';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
    <!--End of Tawk.to Script-->
    <!--Google Analytices Script-->
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async="" src="<?=THEME?>custom/js"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-110581702-2');
    </script>

    <!--End-->

    <style type="text/css">@keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}@-moz-keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}@-webkit-keyframes tawkMaxOpen{0%{opacity:0;transform:translate(0, 30px);;}to{opacity:1;transform:translate(0, 0px);}}#vpPNLgm-1546793010467{outline:none!important;visibility:visible!important;resize:none!important;box-shadow:none!important;overflow:visible!important;background:none!important;opacity:1!important;filter:alpha(opacity=100)!important;-ms-filter:progid:DXImageTransform.Microsoft.Alpha(Opacity1)!important;-moz-opacity:1!important;-khtml-opacity:1!important;top:auto!important;right:10px!important;bottom:90px!important;left:auto!important;position:fixed!important;border:0!important;min-height:0!important;min-width:0!important;max-height:none!important;max-width:none!important;padding:0!important;margin:0!important;-moz-transition-property:none!important;-webkit-transition-property:none!important;-o-transition-property:none!important;transition-property:none!important;transform:none!important;-webkit-transform:none!important;-ms-transform:none!important;width:auto!important;height:auto!important;display:none!important;z-index:2000000000!important;background-color:transparent!important;cursor:auto!important;float:none!important;border-radius:unset!important;}#BcnOUNN-1546793010467.open{animation : tawkMaxOpen .25s ease!important;}</style></head>
<!--Begin wapper-->
<body>

<!--Begin wapper-->
<div id="wrapper">
    <header>
        <div class="mainCntr">
            <!--Begin logo-->
            <div class="logo">
                <a href="https://www.evisaonline.org.in/"><img src="<?=THEME?>custom/banner1.png" alt="e-Tourist Visa" title="e-Tourist Visa"></a>
                <!-- <h4 style="font-size: 26px;font-family: Mistral;font-weight: 100;margin-left: 63px;margin-top: -16px; color: #000;margin-bottom: 10px;">Government of India Scheme</h4>-->
            </div>
            <!--<div class="blank"><p class="blink" style="text-align:justify;margin-left:65px;font-weight:normal">The phone lines will be down today due to the technical issue, the services will resume tomorrow morning at 10 am. The applications will be processed as usual and for any query please email at </br>support@evisaonline.org.in</p></div>-->
            <!--end logo-->
            <!--Begin right-side-->
            <div class="right_side">
                <!--<span><a href="https://www.evisaonline.org.in/"><img src="contact-us.png" title="etaonlineindia contact" alt="etaonlineindia"/></a></span>-->
            </div>
            <!--end right-side-->
        </div>
        <div style="clear:both;"></div>
        <div class="bg">
            <div id="nav">
                <ul>
                    <li><a href="<?=CTRL?>">Home</a></li>
                    <li><a href="<?=CTRL?>Visa/apply_visa" class="active">Apply Now</a></li>
                    <!--<li><a href="holiday.php">Holiday</a></li>
                    <li><a href="index.php">Flight</a></li>
                    <li><a href="flight/hotel.php">Hotel</a></li>-->

                    <li>
                        <a href="<?=CTRL?>Visa/documents">Document Requirement</a>
                    </li>
                    <li>
                        <a href="<?=CTRL?>Visa/privacy">Privacy Policy</a>
                    </li>
                    <li>
                        <a href="<?=CTRL?>Visa/terms">Terms Conditions</a>
                    </li>
                    <li>
                        <a href="<?=CTRL?>Visa/about">About Us</a>
                    </li>
                    <li>
                        <a href="<?=CTRL?>Visa/contact">Contact Us</a>
                    </li>

                </ul>
            </div>
        </div>
    </header>
    <!-- Header End--><!--Begin banner-->
    <!--Begin banner-->
    <div class="clearfix"></div>
    <section class="banner">
        <div class="banner_bg">
            <ul>
                <li><img src="<?=THEME?>custom/slide-banner.jpg" style="height:300px; margin-top: -2px;" alt=""></li>
            </ul>
        </div>
    </section>
    <!--end banner-->            <!--end banner-->

    <div class="clearfix"></div>
    <!--Begin maincntr-->

    <div class="mainCntr">
        <!--Begin button_bottom-->
        <section class="bottom_btn" style="margin-top: 60px;">
            <div class="frt_bt"><p style="margin-top: 10px;"><a  href="<?=CTRL?>Visa/apply_visa">Click here to Apply <br>for Visa</a></p></div>
            <div class="frt_bt1"><p style="margin-top: 10px;"><a href="<?=CTRL?>Visa/partial">Amend or Complete Partialy<br>Filled Form</a></p></div>
            <div class="frt_bt2"><p style="margin-top: 10px;"><a href="<?=CTRL?>Visa/complete_payment">Make Payment for<br>Completed Form</a></p></div>
            <!--	<div class="frt_bt3"><p><a href="">Check Application<br> Status</a></p></div>-->
            <!--div class="frt_bt4"><p><a href="">Visa Status </a></p></div--->
        </section>
        <!--Begin information-->
        <div class="main_ara_new">

            <section class="main_ara">
                <!--Begin left_menu-->
                <div class="left_bar">

                    <div class="left_bar_inner">
                        <h3 style=" margin:-10px 0px 10px 0px;"><img src="<?=THEME?>custom/c6.png">24/7 Customer Care</h3>
                        <img src="<?=THEME?>custom/contact-us.png">
                    </div>

                    <div class="left_bar_inner" style="margin-top: -1px;">
                        <h3 style=" margin:0px 0px 10px 0px;">e-Visa Information</h3>
                        <ul>
                            <li><a href="https://www.evisaonline.org.in/apply-visa">e-Visa India</a></li>
                            <li><a href="https://www.evisaonline.org.in/e-tourist-visa">Tourist E-visa</a></li>
                            <li><a href="https://www.evisaonline.org.in/emergency-e-visa-to-india">Emergency E-visa</a></li>
                            <li><a href="https://www.evisaonline.org.in/how-to-apply-for-an-indian-evisa">How to apply for an Indian E-visa</a></li>
                            <li><a href="https://www.evisaonline.org.in/indian-business-e-visa">Indian Business E-visa</a></li>
                            <li><a href="https://www.evisaonline.org.in/indian-medical-e-visa">Indian Medical E-visa</a></li>
                            <li><a href="https://www.evisaonline.org.in/how-to-get-Indian-visa">How to get Indian Visa Online</a></li>
                            <li><a href="https://www.evisaonline.org.in/indian-e-visa-application-processing-time">Indian E-visa Application Processing Time</a></li>
                            <!--<li><a href="https://www.evisaonline.org.in/">FAQs-Payment Related</a></li>-->
                        </ul>
                    </div>

                    <div class="left_bar_inner">
                        <img src="<?=THEME?>custom/3dsecure.gif" alt="" style="width: 250px;">
                    </div>
                    <div>
                    </div>
                </div>						<!--End left_menu-->

                <!--End left_menu-->

                <!--Begin right-panel-->
                <div class="right_area" id="tvoa">
                    <div class="right_bar_inner">
                        <h1 style="text-transform: none; color:#fff; font-family:Tahoma,Geneva,sans-serif; font-weight:normal;font-size: 17px;text-align:center">e-VISA India</h1></div>

                    <p><span>Terms &amp; Conditions </span><br>
                        The applicants applying for normal e visa services or emergency e visa services have to take cognizance of the fact that the maintenance of internal security is one of the most prioritized aspect of any country. Likewise the government of India too keeps a close eye on the fact that no mischievous elements enter the Indian soil and disturb the peace and harmony here. The e visa application should furnish all the details required for visa approval in the format prescribed by the government. The applicants can go through our Document requirement section in order to make sure that they prepare all the documents in the prescribed format and file size. Apart from this the rules for e visa application are different for different countries. The residents of a select group of countries are eligible to apply for the e visa services. To check if one's country's name appears in the list of countries allowed to apply for e visa services or not he/she can visit our Instructions for applicant section. In this section the applicant can also check if he/she fulfills all the basic criteria required for getting e visa approval.<br><br>

                        The visa approval process is under the sole discretion of the Government of India officials. However we as an organization put our years of experience behind assuring that all our applicants receive their visa approvals on time. But we don't guarantee that the application will always lead to visa approvals owing to a range of factors. It's important that the applicants are informed about the various terms and conditions related to e visa approval. We are explaining the Terms and conditions into simple, easy to understand language so that the applicants are aware about the set of conditions and there is transparency in the whole process of applying for e visas for India.<br><br>


                        <span>e-Visa General Terms and Conditions </span><br>
                        Your passport must be valid for six months from the date of arrival in India. Applicants of the eligible countries are requested to apply online at least 4 days in advance to their expected arrival date with a window of 180 days. The e-Visa for the purpose of Tourism and casual business activities can be used for two entries and for Medical purpose it can be used for three entries. E-Visa is valid for 60 days from the date of the first entry into the Indian territory. e-Visa is allowed for a maximum of two visits in a calendar year. The visa must be availed within its validity period.e-Visa is valid for entry through 25 designated Airports (i.e. Ahmedabad, Amritsar, Bagdogra, Bengaluru, Calicut, Chennai, Chandigarh,Cochin, Coimbatore, Delhi, Gaya, Goa, Guwahati, Hyderabad, Jaipur, Kolkata, Lucknow, Mangalore, Mumbai, Nagpur, Pune, Tiruchirapalli, Trivandrum, Varanasi &amp; Vishakhapatnam) and 5 designated seaports (i.e. Cochin, Goa, Mangalore,Mumbai,Chennai). However, the foreigner can take exit from any of the authorized Immigration Check Posts (ICPs) in India. International Travellers should have return ticket or onward journey ticket, with sufficient money to spend during his/her stay in India.<br><br>

                    </p><p><span>e-Visa Application Related Terms and Conditions</span><br>
                        The applicants are requested to fill the online Visa Application Form with due diligence and submit the same with online payment using a debit or credit card or Internet banking. The applicant is requested to provide correct email ID since we send the e-Visa via email in JPEG or PDF format in attached files. Incomplete application, incorrect information and/or multiple applications may result in rejection of you visa request. <br><br>

                        It is strictly advised to fill and submit only one application against a passport number. Multiple/Redundant applications against the same passport shall lead to rejection of the visa application. The fee is non-refundable in such cases. It is imperative to fill and submit only one application to avoid rejection and loss of visa fees against multiple applications.<br><br>

                        If you are unable to find an existing application then please contact the 24X7 customer case via phone or email. Applications must be filled with due diligence to avoid any errors. Once a visa is issued, it can’t be cancelled, amended or re-issued even though the details in the visa are incorrect until the previously issued visa expires. For any query or help please contact customer care.<br><br>

                    </p><p><span>e-Visa Fee Related Terms and Conditions</span><br>

                    </p><p>Our total fee for normal processing which takes 4-7 business days is 70 USD more than the Indian Government visa fee. Exchange rate is applicable per passenger excluding interchange charge for credit/debit cards. The fee must be paid at least 5 days before the expected date of travel mentioned by you otherwise application will not be processed. Our total fee for processing the application on Fast track is 145  USD more than the Government Visa fee. The visa result is provided in 1-2 business days from the date of submission of the e-Visa application. Exchange rate applicable per passenger excluding interchange charge for credit/debit cards. <br><br> Please note that when you are availing the fast track service then your travel date must be after 48 hours from time of submission of your application. Government of India reserves all rights to make any changes in the requirements and fees for India e-Visa without any prior notice. Fee charges of evisaonline.org.in may include, but are not limited to, Indian Embassy Fees and other charges of the respective embassy (consular fees etc.). We not responsible for any such changes by embassy or for any loss or delay relating to such changes. <br><br>The Govt. fee for the Indian e-visa is USD 100.00, USD 80.00, USD 25.00 which differs from one nationality of the applicant to the other. There is no fee from Govt. for few nationalities. We advise you to check the government fee on official website www.indianvisaonline.gov.in and then pay on our website. Our fee is 70 USD more for normal processing and 145 USD for fast track Processing irrespective of Govt. fee. Visa fees are non-refundable and non-transferrable. Once the application is paid, the fee is non-refundable.
                        We are a service provider and we have no connection with the Government Of India . We are only helping the applicants who want to get a visa to visit India .

                    </p><p><span>e-Visa Issuance Related Terms</span><br>

                        The e-visa result shall be emailed 110 days prior to your expected arrival date in India if you have submitted the application more than 120 days in advance of your expected arrival date. If your application is submitted within 120 days prior to your expected arrival date in India then your visa result shall be emailed within 4 to 7 business days (Excluding Saturdays, Sundays and Indian Public Holidays) from the date of submission. If your travel is within 4 days then your visa result shall be emailed in 1-2 business days. <br><br>

                        All the processing times are valid after receipt of the appropriate documents against each individual application. Indian Visa Centre will not be responsible for any delay in the process due to non-availability of proper documents. Our delivery time is applicable from the time the application is complete with all the information and documents required to process the same.<br><br>

                        These delivery timeframes are not applicable for Sri Lankan and Chinese Passport Holders. For these nationalities the delivery time is 5 business days in case of fast track processing and 10 business days in case of normal processing.<br><br>

                        Please send an email at support@evisaonline.org.in or hello@evisaonline.org.in or call 24/7 customer care if you haven't received the delivery in the above mentioned time.<br><br>

                        Approval or rejection of the visa application depends on the decision of the Government Immigrations department. The visa issuance is subject to the rules of Government of India and they reserve the rights to make any changes in that. www.evisaonline.org.in shall not be liable for any losses or damages, which the applicant may suffer arising from delay in processing or receiving or/and rejection of visa<br><br>

                        Issuance of a visa or approval of visa application does not in any way give the applicant a right to enter India. The entry is at the sole discretion of the Immigration officer at the Indian Airport who is a representative of the Government of India. In case of denial of visa or entry into Indian territory, we shall not be held liable in any manner whatsoever. The applicant is requested to check the correctness of your visa the moment as soon as it is sent and in case of any discrepancy bring it to our notice immediately. We reserves the right to add, amend or alter these terms and conditions at any time without notice or liability and all applicants using our services shall be bound by the same<br><br>

                    </p><p><span>Cancellation and Refund Policy</span><br>

                        Once the application is submitted on our website and the visa fee is paid to the Government of India, it is completely non-refundable. In case you wish to cancel the order and withdraw your application before we have paid the fee against your application to the Government of India then only 50% refund can be requested by writing an email to the customer care. The customer care team should escalate the request and the same shall be confirmed in writing only after getting an approval from the higher authorities.<br><br>

                        The application processing begins as soon as it submitted on our website. So, If you need to withdraw the application then you must write to the customer care as soon as possible to put the application on hold and request for 50% refund. All verbal requests and/or any emails requests that are received after the visa fee has been paid to the Government, shall not be considered. We reserve the right to charge 50% of the total amount as our cancellation fee in case you wish to cancel or withdraw your application before the we have paid the visa fee to the Government of India. Once the visa fee is paid to the Government then the transaction is completely non-refundable.<br><br>


                    </p><p><span>Exclusive Jurisdiction Clause</span><br>

                        Each of the parties to this Agreement irrevocably agrees that the courts of New Delhi, India shall have exclusive jurisdiction to hear and decide any suit, action or proceedings, and/or to settle any disputes, which may arise out of or in connection with the Agreement or its formation or validity and, for these purposes, each party irrevocably submits to the jurisdiction of the courts of New Delhi, India.<br><br></p>
                </div></section>

            <!--Begin visa process-->
            <!--Begin visa process-->
            <section class="visa_process">
                <div class="visa_process_inner"><h4>e-Visa India PROCESS</h4></div>
                <div class="creat">
                    <div class="htw">
                        <div class="how_it">
                        </div>
                        <span style="margin-left: 55px;">Step 1</span>
                        <div class="how_mid box_1" style="float: right;">
                            <img src="<?=THEME?>custom/1.png">
                        </div>
                    </div>

                    <h2 onclick="verify()" style="cursor:pointer;margin-left: 184px;">Apply online</h2>
                    <!--<p>Upload Photo and Passport Page</p>-->
                </div>

                <div class="creat">
                    <!--div class="arw"><img src="Indian%20e-Tourist%20Visa_files/arrow_02.png"></div--->
                    <div class="htw">
                        <div class="how_it"></div>
                        <span style=" margin-left: -39px;">Step 2</span>
                        <div class="how_mid box_1"><img src="<?=THEME?>custom/2.png"></div>
                    </div>
                    <a class="h2a" target="_blank" href="https://www.evisaonline.org.in/welcomevisa/complete_payment">Pay visa fee online</a>
                    <!-- <h2>Pay visa fee online </h2>-->
                    <!-- <p> Using Credit / Debit card </p>-->
                </div>

                <div class="creat">
                    <!--div class="arw"><img src="Indian%20e-Tourist%20Visa_files/arrow_01.png"></div-->
                    <div class="htw">
                        <div class="how_it"></div>
                        <span style=" margin-left: -131px;">Step 3</span>
                        <div class="how_mid box_1" style=" float: left;"><img src="<?=THEME?>custom/3.png"></div>
                    </div>
                    <h2 style=" margin-left: -182px;">Receive e-Visa Electronically</h2>
                    <!-- <p> eTV Will be sent to your e-mail </p>-->
                </div>
            </section>
            <!--End visa process-->
            <!--End visa process-->
            <div class="clear"></div>

        </div>
    </div>
    <!--End maincntr--><footer>
        <div class="mainCntr">
            <div class="footer_logo box_1"><img src="<?=THEME?>custom/payment-options1.png">
                <p align="right" style="margin-left: -10px;">©copyright 2017 by www.evisaonline.org.in</p></div>
            <span id="siteseal" style="margin-left: 22px;">
</span>
            <div class="footer_left">


            </div>

            <div class="footer_text">
                <div align="justify"><strong style="font-size:12px; font-weight: normal;">
                        <div class="footercontain" style="color:#000; text-align:justify; margin-left:10px;">
                            <div align="justify"><strong style="font-size:12px; font-weight: normal;"><b style="font-size:14px; color:#f48020;">*Disclaimer:</b>
                                    www.evisaonline.org.in website provides you e-visa services to India. This is a commercial website to apply for visa to India where you will be charged a fee for using our services. You can also apply through the direct official source. Kindly read all our Terms and Conditions carefully before using our services.
                                </strong></div>
                        </div>
                    </strong></div><strong style="font-size:12px; font-weight: normal;">

                </strong></div><strong style="font-size:12px; font-weight: normal;">

            </strong></div><strong style="font-size:12px; font-weight: normal;">
        </strong></footer><strong style="font-size:12px; font-weight: normal;">
    </strong></div><strong style="font-size:12px; font-weight: normal;">
    <!--Begin wapper-->
</strong><div id="vpPNLgm-1546793010467" class="" style="display: none !important;"><iframe id="BcnOUNN-1546793010467" src="<?=THEME?>custom/saved_resource.html" frameborder="0" scrolling="no" title="chat widget" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: auto !important; right: auto !important; bottom: auto !important; left: auto !important; position: static !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 350px !important; height: 520px !important; display: none !important; z-index: 999999 !important; cursor: auto !important; float: none !important; border-radius: unset !important;"></iframe><iframe id="PpBt1hp-1546793010468" src="<?=THEME?>custom/saved_resource(1).html" frameborder="0" scrolling="no" title="chat widget" class="" style="outline: none !important; visibility: visible !important; resize: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; position: fixed !important; border: 0px !important; padding: 0px !important; transition-property: none !important; display: none !important; z-index: 1000001 !important; cursor: auto !important; float: none !important; box-shadow: rgba(0, 0, 0, 0.16) 0px 2px 10px 0px !important; height: 60px !important; min-height: 60px !important; max-height: 60px !important; width: 60px !important; min-width: 60px !important; max-width: 60px !important; border-radius: 50% !important; transform: rotate(0deg) translateZ(0px) !important; transform-origin: 0px center 0px !important; margin: 0px !important; top: auto !important; bottom: 20px !important; right: 20px !important; left: auto !important;"></iframe><iframe id="m28zmu0-1546793010468" src="<?=THEME?>custom/saved_resource(2).html" frameborder="0" scrolling="no" title="chat widget" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; position: fixed !important; border: 0px !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; display: none !important; z-index: 1000003 !important; cursor: auto !important; float: none !important; border-radius: unset !important; top: auto !important; bottom: 60px !important; right: 15px !important; left: auto !important; width: 21px !important; max-width: 21px !important; min-width: 21px !important; height: 21px !important; max-height: 21px !important; min-height: 21px !important;"></iframe><div class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: 0px !important; right: auto !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 100% !important; height: 100% !important; display: none !important; z-index: 1000001 !important; cursor: move !important; float: left !important; border-radius: unset !important;"></div><div id="jfxDpoF-1546793010467" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: 0px !important; right: auto !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 6px !important; height: 100% !important; display: block !important; z-index: 999998 !important; cursor: w-resize !important; float: none !important; border-radius: unset !important;"></div><div id="cyP4YVe-1546793010467" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: 0px !important; right: 0px !important; bottom: auto !important; left: auto !important; position: absolute !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 100% !important; height: 6px !important; display: block !important; z-index: 999998 !important; cursor: n-resize !important; float: none !important; border-radius: unset !important;"></div><div id="tCqzj6m-1546793010467" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: 0px !important; right: auto !important; bottom: auto !important; left: 0px !important; position: absolute !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 12px !important; height: 12px !important; display: block !important; z-index: 999998 !important; cursor: nw-resize !important; float: none !important; border-radius: unset !important;"></div><iframe id="xP8E7SI-1546793010619" src="<?=THEME?>custom/saved_resource(3).html" frameborder="0" scrolling="no" title="chat widget" class="" style="outline: none !important; visibility: visible !important; resize: none !important; box-shadow: none !important; overflow: visible !important; background: none transparent !important; opacity: 1 !important; top: auto !important; right: 20px !important; bottom: 90px !important; left: auto !important; position: fixed !important; border: 0px !important; min-height: auto !important; min-width: auto !important; max-height: none !important; max-width: none !important; padding: 0px !important; margin: 0px !important; transition-property: none !important; transform: none !important; width: 378px !important; height: 472px !important; display: none !important; z-index: 999999 !important; cursor: auto !important; float: none !important; border-radius: unset !important;"></iframe></div></body></html>
