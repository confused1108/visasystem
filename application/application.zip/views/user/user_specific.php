<?php
/**
 * Created by PhpStorm.
 * User: Hitesh
 * Date: 21-Sep-18
 * Time: 3:58 PM
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?=THEME?>assets/images/favicon.png">
    <title>Talent System</title>
    <!-- Custom CSS -->
    <link href="<?=THEME?>dist/css/style.min.css" rel="stylesheet">
    <link href="<?=THEME?>assets/libs/toastr/build/toastr.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
    <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
    </div>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper">
    <!-- ============================================================== -->
    <!-- Topbar header - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <header class="topbar" data-navbarbg="skin5">
        <nav class="navbar top-navbar navbar-expand-md navbar-dark">
            <div class="navbar-header" data-logobg="skin5">
                <!-- This is for the sidebar toggle which is visible on mobile only -->
                <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                <!-- ============================================================== -->
                <!-- Logo -->
                <!-- ============================================================== -->
                <a class="navbar-brand" href="index.html">
                    <!-- Logo icon -->
                    <b class="logo-icon p-l-10">
                        <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                        <!-- Dark Logo icon -->
                        <img src="<?=THEME?>assets/images/logo-icon.png" alt="homepage" class="light-logo" />

                    </b>
                    <!--End Logo icon -->
                    <!-- Logo text -->
                    <span class="logo-text">
                             <!-- dark Logo text -->
                             <img src="<?=THEME?>assets/images/logo-text.png" alt="homepage" class="light-logo" />

                        </span>
                    <!-- Logo icon -->
                    <!-- <b class="logo-icon"> -->
                    <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                    <!-- Dark Logo icon -->
                    <!-- <img src="<?=THEME?>assets/images/logo-text.png" alt="homepage" class="light-logo" /> -->

                    <!-- </b> -->
                    <!--End Logo icon -->
                </a>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Toggle which is visible on mobile only -->
                <!-- ============================================================== -->
                <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
            </div>
            <!-- ============================================================== -->
            <!-- End Logo -->
            <!-- ============================================================== -->
            <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                <!-- ============================================================== -->
                <!-- toggle and nav items -->
                <!-- ============================================================== -->
                <ul class="navbar-nav float-left mr-auto">
                    <li class="nav-item d-none d-md-block"><a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
                    <!-- ============================================================== -->
                    <!-- create new -->
                    <!-- ============================================================== -->
                    
                    <!-- ============================================================== -->
                    <!-- Search -->
                    <!-- ============================================================== -->
                    
                </ul>
                <!-- ============================================================== -->
                <!-- Right side toggle and nav items -->
                <!-- ============================================================== -->
                
            </div>
        </nav>
    </header>
    <!-- ============================================================== -->
    <!-- End Topbar header -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <?php include "includes/aside.php"; ?> 

    <!-- ============================================================== -->
    <!-- End Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Page wrapper  -->
    <!-- ============================================================== -->
    <div class="page-wrapper">
        <div class="container-fluid  align-items-center" style="min-height: 100vh;">
            <h1 class="text-center my-5" >Choose Characterstics</h1>
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="card card-hover" style="width:90%;margin-left:5%;">
                        <button type="button" class="btn btn-success btn-lg" data-toggle="modal" data-target="#Modal111" >
<!--                            <a href="--><?//=CTRL?><!--User/user_new_specific/--><?php //echo $this->uri->segment('3'); ?><!--" style="text-decoration: none; color: white;">-->
                                <h1 class="font-light text-white">
                                    <i class="mdi mdi-chart-areaspline"></i>
                                </h1>Based on Specific Characteristics
                                <!--                            </a>-->
                        </button>
                    </div>
                </div>
                <div class="modal fade" id="Modal111" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true ">
                    <div class="modal-dialog" role="document ">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Select Details</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true ">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="post" action="<?=CTRL?>User/user_new_specific/<?php echo $this->uri->segment('3'); ?>" >
                                    <div class="form-group row" data-select2-id="12">
                                        <label for="cono1" class="col-sm-3 text-right control-label col-form-label">Age</label>
                                        <div class="col-md-12" data-select2-id="11">
                                            <select name="age" class="select2 form-control custom-select select2-hidden-accessible" style="width: 100%; height:36px;" data-select2-id="1" tabindex="-1" aria-hidden="true">
                                                <?php

                                                $arr = explode( ',' , $agedata[0]['age']);
                                                foreach($arr as $a){

                                                            ?>
                                                    <option value="<?php echo $a; ?>"><?php
                                                        if($a=='1')
                                                            echo "8-9 Years";
                                                        elseif($a=='2')
                                                            echo "10-11 Years";
                                                        elseif($a=='3')
                                                            echo "12-13 Years";
                                                        elseif($a=='4')
                                                            echo "14-16 Years";
                                                        ?></option>
                                                    <?php

                                                }
                                                ?>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row" data-select2-id="12">
                                        <label for="cono1" class="col-sm-3 text-right control-label col-form-label">Gender</label>
                                        <div class="col-md-12" data-select2-id="11">
                                            <select name="gender" class="select2 form-control custom-select select2-hidden-accessible" style="width: 100%; height:36px;" data-select2-id="1" tabindex="-1" aria-hidden="true">
                                                <option value="male">Male</option>
                                                <option value="female">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="border-top">
                                        <div class="card-body">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-12 col-md-12">
                    <div class="card card-hover" style="width:90%;margin-left:5%;">
                        <button type="button" class="btn btn-danger btn-lg" data-toggle="modal" data-target="#Modal222">
                            <!--<a href="<?=CTRL?>User/user_new_genetic/<?php echo $this->uri->segment('3'); ?>" style="text-decoration: none; color: white;">-->
                            <h1 class="font-light text-white">
                                <i class="mdi mdi-chart-areaspline"></i>
                            </h1>Based on Genetic Characteristics
                            <!--</a>-->
                        </button>
                    </div>
                </div>

				<div class="modal fade" id="Modal222" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true ">
                    <div class="modal-dialog" role="document ">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Select Details</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true ">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="post" action="<?=CTRL?>User/user_new_genetic/<?php echo $this->uri->segment('3'); ?>" >
                                    <div class="form-group row" data-select2-id="12">
                                        <label for="cono1" class="col-sm-3 text-right control-label col-form-label">Age</label>
                                        <div class="col-md-12" data-select2-id="11">
                                            <select name="age" class="select2 form-control custom-select select2-hidden-accessible" style="width: 100%; height:36px;" data-select2-id="1" tabindex="-1" aria-hidden="true">
                                                <?php

                                                $arr = explode( ',' , $agedata[0]['age']);
                                                foreach($arr as $a){

                                                    ?>
                                                    <option value="<?php echo $a; ?>"><?php
                                                        if($a=='1')
                                                            echo "8-9 Years";
                                                        elseif($a=='2')
                                                            echo "10-11 Years";
                                                        elseif($a=='3')
                                                            echo "12-13 Years";
                                                        elseif($a=='4')
                                                            echo "14-16 Years";
                                                        ?></option>
                                                    <?php

                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row" data-select2-id="12">
                                        <label for="cono1" class="col-sm-3 text-right control-label col-form-label">Gender</label>
                                        <div class="col-md-12" data-select2-id="11">
                                            <select name="gender" class="select2 form-control custom-select select2-hidden-accessible" style="width: 100%; height:36px;" data-select2-id="1" tabindex="-1" aria-hidden="true">
                                                <option value="male">Male</option>
                                                <option value="female">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="border-top">
                                        <div class="card-body">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
				
                <div class="col-lg-12 col-md-12">
                    <div class="card card-hover" style="width:90%;margin-left:5%;">
                        <button type="button" class="btn btn-warning btn-lg" data-toggle="modal" data-target="#Modal333">
                            <h1 class="font-light text-white">
                                <i class="mdi mdi-chart-areaspline"></i>
                            </h1>Based on Both Specific and Genetic
                        </button>
                    </div>
                </div>
                <div class="modal fade" id="Modal333" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true ">
                    <div class="modal-dialog" role="document ">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Select Details</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true ">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="post" action="<?=CTRL?>User/user_new_both/<?php echo $this->uri->segment('3'); ?>" >
                                    <div class="form-group row" data-select2-id="12">
                                        <label for="cono1" class="col-sm-3 text-right control-label col-form-label">Age</label>
                                        <div class="col-md-12" data-select2-id="11">
                                            <select name="age" class="select2 form-control custom-select select2-hidden-accessible" style="width: 100%; height:36px;" data-select2-id="1" tabindex="-1" aria-hidden="true">
                                                <?php

                                                $arr = explode( ',' , $agedata[0]['age']);
                                                foreach($arr as $a){

                                                    ?>
                                                    <option value="<?php echo $a; ?>"><?php
                                                        if($a=='1')
                                                            echo "8-9 Years";
                                                        elseif($a=='2')
                                                            echo "10-11 Years";
                                                        elseif($a=='3')
                                                            echo "12-13 Years";
                                                        elseif($a=='4')
                                                            echo "14-16 Years";
                                                        ?></option>
                                                    <?php

                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group row" data-select2-id="12">
                                        <label for="cono1" class="col-sm-3 text-right control-label col-form-label">Gender</label>
                                        <div class="col-md-12" data-select2-id="11">
                                            <select name="gender" class="select2 form-control custom-select select2-hidden-accessible" style="width: 100%; height:36px;" data-select2-id="1" tabindex="-1" aria-hidden="true">
                                                <option value="male">Male</option>
                                                <option value="female">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="border-top">
                                        <div class="card-body">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?=THEME?>assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?=THEME?>assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?=THEME?>assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?=THEME?>assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="<?=THEME?>assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="<?=THEME?>dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?=THEME?>dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?=THEME?>dist/js/custom.min.js"></script>
    <!-- this page js -->
    <script src="<?=THEME?>assets/libs/toastr/build/toastr.min.js"></script>
    <script>
        $(function(){
            // Success Type
            $('#ts-success').on('click', function() {
                toastr.success('Have fun storming the castle!', 'Miracle Max Says');
            });

            // Success Type
            $('#ts-info').on('click', function() {
                toastr.info('We do have the Kapua suite available.', 'Turtle Bay Resort');
            });

            // Success Type
            $('#ts-warning').on('click', function() {
                toastr.warning('My name is Inigo Montoya. You killed my father, prepare to die!');
            });

            // Success Type
            $('#ts-error').on('click', function() {
                toastr.error('I do not think that word means what you think it means.', 'Inconceivable!');
            });
        });
    </script>
</body>

</html>
