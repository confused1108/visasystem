<?php
/**
 * Created by PhpStorm.
 * User: Hitesh
 * Date: 28-Sep-18
 * Time: 4:19 PM
 */
?>
<?php
/**
 * Created by PhpStorm.
 * User: Hitesh
 * Date: 21-Sep-18
 * Time: 3:59 PM
 */
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?=THEME?>assets/images/favicon.png">
    <title>Talent System</title>
    <!-- Custom CSS -->
    <link href="<?=THEME?>assets/libs/jquery-steps/jquery.steps.css" rel="stylesheet">
    <link href="<?=THEME?>assets/libs/jquery-steps/steps.css" rel="stylesheet">
    <link href="<?=THEME?>dist/css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
    <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
    </div>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper">
    <!-- ============================================================== -->
    <!-- Topbar header - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <header class="topbar" data-navbarbg="skin5">
        <nav class="navbar top-navbar navbar-expand-md navbar-dark">
            <div class="navbar-header" data-logobg="skin5">
                <!-- This is for the sidebar toggle which is visible on mobile only -->
                <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                <!-- ============================================================== -->
                <!-- Logo -->
                <!-- ============================================================== -->
                <a class="navbar-brand" href="index.html">
                    <!-- Logo icon -->
                    <b class="logo-icon p-l-10">
                        <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                        <!-- Dark Logo icon -->
                        <img src="<?=THEME?>assets/images/logo-icon.png" alt="homepage" class="light-logo" />

                    </b>
                    <!--End Logo icon -->
                    <!-- Logo text -->
                    <span class="logo-text">
                             <!-- dark Logo text -->
                             <img src="<?=THEME?>assets/images/logo-text.png" alt="homepage" class="light-logo" />

                        </span>
                    <!-- Logo icon -->
                    <!-- <b class="logo-icon"> -->
                    <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                    <!-- Dark Logo icon -->
                    <!-- <img src="<?=THEME?>assets/images/logo-text.png" alt="homepage" class="light-logo" /> -->

                    <!-- </b> -->
                    <!--End Logo icon -->
                </a>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Toggle which is visible on mobile only -->
                <!-- ============================================================== -->
                <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
            </div>
            <!-- ============================================================== -->
            <!-- End Logo -->
            <!-- ============================================================== -->
            <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                <!-- ============================================================== -->
                <!-- toggle and nav items -->
                <!-- ============================================================== -->
                <ul class="navbar-nav float-left mr-auto">
                    <li class="nav-item d-none d-md-block"><a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
                    <!-- ============================================================== -->
                    <!-- create new -->
                    <!-- ============================================================== -->
                   
                </ul>
            </div>
        </nav>
    </header>
    <!-- ============================================================== -->
    <!-- End Topbar header -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <?php include "includes/aside.php"; ?> 

    <!-- ============================================================== -->
    <!-- End Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Page wrapper  -->
    <!-- ============================================================== -->
    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->

        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
            
			<h3 style="text-align:center;"><?php echo $category;?></h3>
			<h6 style="text-align:center;">(<span style="color:blue;"> Gender </span> : <?php echo $gender; ?>,<span style="color:blue;"> Age </span> : <?php
                                            if($age=='1')
                                                echo "8-9 Years";
                                            elseif($age=='2')
                                                echo "10-11 Years";
                                            elseif($age=='3')
                                                echo "12-13 Years";
                                            elseif($age =='4')
                                                echo "14-16 Years";
                                            else
                                                echo $age;
                                            ?> )</h6>
            <!-- ============================================================== -->
            <!-- Start Page Content -->
            <!-- ============================================================== -->
            <div class="card" id="add_field_in">
<div class="my-1 text-right">
			
                <a href="<?=CTRL?>User/multiple_users/<?php echo $this->uri->segment('3'); ?>/5/<?php echo $age; ?>/<?php echo $gender;?>">
                    <div class="btn btn-info">
                        Compute for Multiple Users
                    </div>
                </a>
            </div>
                <div class="card-body wizard-content kaus-add-here">
                    <span>
                        <h4 class="card-title">Enter Details</h4>
                    
                    
<!--                    <a href="#" style="float: right;margin-bottom: 20px;" id="removeform" >-->
<!--                        <div class="btn btn-danger">-->
<!--                        Delete-->
<!--                        </div>-->
<!--                    </a>-->
                    </span>
                    <h6 class="card-subtitle"></h6>

                    <form id="example-form" method="post" action="<?=CTRL?>User/submit_sporting/<?php echo $term; ?>" class="m-t-40">
                        <div>
                            <h3>Personal Details</h3>
                            <section>
                                <div class="row">
                                    <div class="col-lg-6 col-sm-12">
                                        <label for="idNumber">Aadhaar Number</label>
                                        <input id="idNumber" name="idnumber" type="text" class="form-control">
                                    </div>
                                    <div class="col-lg-6 col-sm-12">
                                        <label for="userName">Name <span style="color:red;">*</span></label>
                                        <input id="userName" name="name" type="text" class="required form-control">
                                    </div>
                                        <div class="col-lg-6 col-sm-12">
                                            <label >Age Group</label>
                                            <input id="idNumber" name="age" value="<?php
                                            if($age=='1')
                                                echo "8-9 Years";
                                            elseif($age=='2')
                                                echo "10-11 Years";
                                            elseif($age=='3')
                                                echo "12-13 Years";
                                            elseif($age =='4')
                                                echo "14-16 Years";
                                            else
                                                echo "NA";
                                            ?>" readonly type="text" class="form-control">
                                        </div>
                                        <div class="col-lg-6 col-sm-12">
                                            <label >Gender</label>
                                            <input id="idNumber" name="gender" value="<?php echo $gender; ?>" readonly type="text" class="form-control">

                                        </div>
<!--                                    <div class="col-lg-12 col-sm-12">-->
                                        <!--                                        <label for="usermail">Email</label>-->
                                        <input id="usermail" name="email" type="mail" class="form-control" value=" " hidden>
                                        <!--                                    </div>-->
                                        <!--                                    <div class="col-lg-6 col-sm-12">-->
                                        <!--                                        <label for="userNumber">Phone Number </label>-->
                                        <input id="userNumber" name="phone" type="text" class="form-control" value=" " hidden>
                                        <!--                                    </div>-->
                                        <!--                                    <div class="col-lg-6 col-sm-12">-->
                                        <!--                                        <label for="userCity">City <span style="color:red;">*</span></label>-->
                                        <input id="userCity" name="city" type="text" class="required form-control" value=" " hidden>
                                        <!--                                    </div>-->
                                        <!--                                    <div class="col-lg-6 col-sm-12">-->
                                        <!--                                        <label for="userDistrict">State <span style="color:red;">*</span></label>-->
                                        <input id="userDistrict" name="state" type="text" class="required form-control" value=" " hidden>
                                        <!--                                    </div>-->
                                        <!--                                    <div class="col-lg-6 col-sm-12">-->
                                        <!--                                        <label for="userState">Country </label>-->
                                        <input id="userState" name="country" type="text" class="form-control" value=" " hidden>
                                        <!--                                    </div>-->
                                    <p>(*) Mandatory</p>
                                </div>

                            </section>
                            <?php  if($term=='both') { ?>
                                <h3>Specific Details</h3>
                                <section>
                                    <div class="row">
                                        <?php
                                        foreach ($paramdata as $val) {
                                            ?>
                                            <div class="col-lg-6 col-sm-12">
                                                <label for="sample1"><?php echo $val['name']; ?> <span style="color:red;">*</span></label>
                                                <span class="mx-3" data-toggle="modal" data-target="#modal_<?php echo $val['param_id']; ?>" ><i class="fas fa-question-circle"></i></span>
                                                <input name="parid[]" style="display: none;" value="<?php echo $val['param_id']; ?>">
                                                <input id="sample1" name="parinp[]" type="number" step=".0001" min="<?php echo 0.75*$val['min']; ?>" max="<?php echo 1.25*$val['max']; ?>" class="required form-control">
                                                <div class="modal fade" id="modal_<?php echo $val['param_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true ">
                                                    <div class="modal-dialog" role="document ">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">How to measure</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true ">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="container">
                                                                    <ul class="nav nav-pills" style="list-style-type:none">
                                                                        <li class="active" style="padding: 10px; border: 2px solid #4bff77; border-radius: 3px; background-color: #4bff77;"><a data-toggle="pill" href="#122_<?php echo $val['param_id']; ?>">Measure</a></li>
                                                                        <li class=""  style="padding: 10px; border: 2px solid #4bff77; border-radius: 3px; margin-left: 20px; background-color: #4bff77;" ><a data-toggle="pill" href="#254_<?php echo $val['param_id']; ?>">Video</a></li>
                                                                    </ul>

                                                                    <div class="tab-content">
                                                                        <div id="122_<?php echo $val['param_id']; ?>" class="tab-pane fade in active">
                                                                            <br><br>
                                                                            <?php echo $val['how_to']; ?>
                                                                        </div>
                                                                        <div id="254_<?php echo $val['param_id']; ?>" class="tab-pane fade">
                                                                            <br><br>
                                                                            <video width="400" controls>
                                                                                <source src="<?php echo URL; echo "uploads/"; echo $val['video']; ?>" type="video/mp4">
                                                                                Your browser does not support HTML5 video.
                                                                            </video>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>

                                    <p><span style="color:red;">*</span> Mandatory</p>
                                </section>
                                <h3>Genetic Details</h3>
                                <section>
                                    <div class="row">
                                        <?php
                                        foreach ($paramdata1 as $val) {
                                            ?>
                                            <div class="col-lg-6 col-sm-12">
                                                <label for="sample1"><?php echo $val['name']; ?> <span style="color:red;">*</span></label>
                                                <span class="mx-3" data-toggle="modal" data-target="#modal_<?php echo $val['param_id']; ?>" ><i class="fas fa-question-circle"></i></span>
                                                <input name="parid[]" style="display: none;" value="<?php echo $val['param_id']; ?>">
                                                <input id="sample1" name="parinp[]" type="number" step=".0001" min="<?php echo 0.75*$val['min']; ?>" max="<?php echo 1.25*$val['max']; ?>" class="required form-control">
                                                <div class="modal fade" id="modal_<?php echo $val['param_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true ">
                                                    <div class="modal-dialog" role="document ">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">How to measure</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true ">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="container">
                                                                    <ul class="nav nav-pills" style="list-style-type:none">
                                                                        <li class="active" style="padding: 10px; border: 2px solid #4bff77; border-radius: 3px; background-color: #4bff77;"><a data-toggle="pill" href="#122_<?php echo $val['param_id']; ?>">Measure</a></li>
                                                                        <li class=""  style="padding: 10px; border: 2px solid #4bff77; border-radius: 3px; margin-left: 20px; background-color: #4bff77;" ><a data-toggle="pill" href="#254_<?php echo $val['param_id']; ?>">Video</a></li>
                                                                    </ul>

                                                                    <div class="tab-content">
                                                                        <div id="122_<?php echo $val['param_id']; ?>" class="tab-pane fade in active">
                                                                            <br><br>
                                                                            <?php echo $val['how_to']; ?>
                                                                        </div>
                                                                        <div id="254_<?php echo $val['param_id']; ?>" class="tab-pane fade">
                                                                            <br><br>
                                                                            <video width="400" controls>
                                                                                <source src="<?php echo URL; echo "uploads/"; echo $val['video']; ?>" type="video/mp4">
                                                                                Your browser does not support HTML5 video.
                                                                            </video>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>

                                    <p><span style="color:red;">*</span> Mandatory</p>
                                </section>
                                <?php
                            } else {
                                ?>
                                <h3><?php echo $term; ?> Details</h3>
                                <section>
                                    <div class="row">
                                        <?php
                                        foreach ($paramdata as $val) {
                                            ?>
                                            <div class="col-lg-6 col-sm-12">
                                                <label for="sample1"><?php echo $val['name']; ?> <span style="color:red;">*</span></label>
                                                <span class="mx-3" data-toggle="modal" data-target="#modal_<?php echo $val['param_id']; ?>" ><i class="fas fa-question-circle"></i></span>
                                                <input name="parid[]" style="display: none;" value="<?php echo $val['param_id']; ?>">
                                                <input id="sample1" name="parinp[]" type="number" step=".0001" min="<?php echo 0.75*$val['min']; ?>" max="<?php echo 1.25*$val['max']; ?>" class="required form-control">
                                                <div class="modal fade" id="modal_<?php echo $val['param_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true ">
                                                    <div class="modal-dialog" role="document ">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">How to measure</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true ">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="container">
                                                                    <ul class="nav nav-pills" style="list-style-type:none">
                                                                        <li class="active" style="padding: 10px; border: 2px solid #4bff77; border-radius: 3px; background-color: #4bff77;"><a data-toggle="pill" href="#122_<?php echo $val['param_id']; ?>">Measure</a></li>
                                                                        <li class=""  style="padding: 10px; border: 2px solid #4bff77; border-radius: 3px; margin-left: 20px; background-color: #4bff77;" ><a data-toggle="pill" href="#254_<?php echo $val['param_id']; ?>">Video</a></li>
                                                                    </ul>

                                                                    <div class="tab-content">
                                                                        <div id="122_<?php echo $val['param_id']; ?>" class="tab-pane fade in active">
                                                                            <br><br>
                                                                            <?php echo $val['how_to']; ?>
                                                                        </div>
                                                                        <div id="254_<?php echo $val['param_id']; ?>" class="tab-pane fade">
                                                                            <br><br>
                                                                            <video width="400" controls>
                                                                                <source src="<?php echo URL; echo "uploads/"; echo $val['video']; ?>" type="video/mp4">
                                                                                Your browser does not support HTML5 video.
                                                                            </video>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>

                                    <p><span style="color:red;">*</span> Mandatory</p>
                                </section>
                                <?php
                            }
                            ?>
                        </div>
                    </form>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End PAge Content -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Right sidebar -->
            <!-- ============================================================== -->
            <!-- .right-sidebar -->
            <!-- ============================================================== -->
            <!-- End Right sidebar -->
            <!-- ============================================================== -->
        </div>
    </div>
</div>
<script src="<?=THEME?>assets/libs/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="<?=THEME?>assets/libs/popper.js/dist/umd/popper.min.js"></script>
<script src="<?=THEME?>assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="<?=THEME?>assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
<script src="<?=THEME?>assets/extra-libs/sparkline/sparkline.js"></script>
<!--Wave Effects -->
<script src="<?=THEME?>dist/js/waves.js"></script>
<!--Menu sidebar -->
<script src="<?=THEME?>dist/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="<?=THEME?>dist/js/custom.min.js"></script>
<!-- this page js -->
<script src="<?=THEME?>assets/libs/jquery-steps/build/jquery.steps.min.js"></script>
<script src="<?=THEME?>assets/libs/jquery-validation/dist/jquery.validate.min.js"></script>
<script>
    // Basic Example with form
    var form = $("#example-form");
    form.validate({
        errorPlacement: function errorPlacement(error, element) { element.before(error); },
        rules: {
            confirm: {
                equalTo: "#password"
            }
        }
    });
    form.children("div").steps({
        headerTag: "h3",
        bodyTag: "section",
        transitionEffect: "slideLeft",
        onStepChanging: function(event, currentIndex, newIndex) {
            form.validate().settings.ignore = ":disabled,:hidden";
            return form.valid();
        },
        onFinishing: function(event, currentIndex) {
            form.validate().settings.ignore = ":disabled";
            return form.valid();
        },
        onFinished: function(event, currentIndex) {
            $( "#example-form" ).submit();
        }
    });


//as is showing error in browser

</script>
</body>

</html>

