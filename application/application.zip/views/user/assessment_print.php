<?php
/**
 * Created by PhpStorm.
 * User: Hitesh
 * Date: 23-Nov-18
 * Time: 12:29 AM
 * Coded by Hitesh with love
 * Find me at confused1108.github.io
 */
?>
<html>
<head>
    <title>Certificate of Assessment</title>
</head>
<body>
<?php
foreach ($userdata as $val) {
    ?>
    <div style="width:900px; height:500px; padding:20px; text-align:center; border: 10px solid #787878; margin-left: auto; margin-right: auto; display: block;">
        <div style="width:850px; height:450px; padding:20px; text-align:center; border: 5px solid #787878">
            <span style="font-size:50px; font-weight:bold">Certificate of Assessment</span>
            <br><br>
            <span style="font-size:25px"><i>This is to certify that</i></span>
            <br><br>
            <span style="font-size:30px"><b><?php echo $val['name']; ?></b></span><br/><br/>
            <span style="font-size:25px"><i>has done assessment of the sport</i></span> <br/><br/>
            <span style="font-size:30px"><b><?php echo $val['cname']; ?></b></span> <br/><br/>
            <span style="font-size:20px">on basis of <b><?php echo $val['based_on']; ?></b> details</span> <br/><br/>
            <span style="font-size:20px">with total score of <b><?php echo $val['overall_score']; ?></b> and <?php if($val['gender']=='male') echo "his"; else echo "her"; ?> selection is <b><?php echo $val['talent_status']; ?></b></span> <br/><br/><br/><br/>
        </div>
    </div>
    <?php
}
?>
</body>
</html>